// SPDX-License-Identifier: GPL-2.0-or-later
// SPDX-FileCopyrightText: 2017-2021 Bartosz Golaszewski <bartekgola@gmail.com>

#define CATCH_CONFIG_MAIN
#include <catch2/catch.hpp>
