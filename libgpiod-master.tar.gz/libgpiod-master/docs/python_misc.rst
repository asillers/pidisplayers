..
   SPDX-License-Identifier: CC-BY-SA-4.0
   SPDX-FileCopyrightText: 2024-2025 Bartosz Golaszewski <bartosz.golaszewski@linaro.org>

..
   This file is part of libgpiod.

libgpiod python bindings misc
=============================

.. autofunction:: gpiod.is_gpiochip_device

.. autofunction:: gpiod.request_lines
