/* SPDX-License-Identifier: Apache-2.0 OR BSD-3-Clause */
/* SPDX-FileCopyrightText: 2023 Linaro Ltd. */
/* SPDX-FileCopyrightText: 2023 Erik Schilling <erik.schilling@linaro.org> */

#include <gpiod.h>
